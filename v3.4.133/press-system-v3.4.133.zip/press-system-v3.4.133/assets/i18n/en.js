export const languageMeta = { label: 'English' };

const translations = {
    ui: {
      allPosts: 'All Posts',
      searchTab: 'Search',
      postTab: 'Post',
      prev: 'Prev',
      next: 'Next',
      contents: 'Contents',
      loading: 'Loading…',
      top: 'Top',
      minRead: 'min read',
      close: 'Close',
      copyLink: 'Copy link',
      linkCopied: 'Link copied',
      versionLabel: 'Version',
      versionsCount: (n) => `${n} versions`,
      latestSuffix: '(latest)',
      outdatedWarning: 'Caution: This blog post may contain outdated information as it has been published a long time ago.',
      notFound: 'Not Found',
      pageUnavailable: 'Page Unavailable',
      indexUnavailable: 'Index unavailable',
      backToAllPosts: 'Back to all posts',
      backToHome: 'Back to home',
      noResultsTitle: 'No results',
      noResultsBody: (q) => `No posts found for "${q}".`,
      tags: 'Tags',
      tagSearch: (tag) => `Tag: ${tag}`,
      allTags: 'All tags',
      more: 'More',
      less: 'Less',
      details: 'Details',
      copyDetails: 'Copy details',
      reportIssue: 'Report issue',
      warning: 'Warning',
      error: 'Error',
      aiFlagLabel: 'AI-assisted',
      aiFlagTooltip: 'AI-assisted: generated or edited with an LLM',
      draftBadge: 'Draft',
      draftNotice: 'This post is a draft and may change.',
      protectedBadge: 'Protected',
      protectedExcerpt: 'Protected article',
      protectedPostBody: 'This article is encrypted. Enter its password to read it.',
      protectedPostPasswordLabel: 'Password',
      protectedPostUnlock: 'Unlock',
      protectedPostUnlocking: 'Unlocking…',
      protectedPostWrongPassword: 'That password did not unlock this article.'
    },
    code: {
      copy: 'Copy',
      copied: 'Copied!',
      failed: 'Copy failed',
      copyAria: 'Copy code'
    },
    errors: {
      postNotFoundTitle: 'Post not found',
      postNotFoundBody: 'The requested post could not be loaded.',
      protectedPostInvalidTitle: 'Protected post unavailable',
      protectedPostInvalidBody: 'This protected article has invalid encryption metadata.',
      pageUnavailableTitle: 'Page unavailable',
      pageUnavailableBody: 'Could not load this tab.',
      indexUnavailableBody: 'Could not load the post index. Check network or repository contents.'
    },
    sidebar: {
      searchPlaceholder: 'Search posts...',
      siteTitle: "Phyllali's Blog",
      siteSubtitle: 'Thanks for playing my game.',
      socialGithub: 'GitHub'
    },
    tools: {
      sectionTitle: 'Function Area',
      toggleTheme: 'Toggle Theme',
      postEditor: 'Markdown Editor',
      themePack: 'Theme pack',
      language: 'Language',
      resetLanguage: 'Reset language'
    },
    toc: {
      toggleAria: 'Toggle section',
      copied: 'Copied!'
    },
    titles: {
      allPosts: 'All Posts',
      search: (q) => `Search: ${q}`
    },
    editor: {
      pageTitle: 'Markdown Editor - Press',
      languageLabel: 'Language',
      verifying: 'Verifying…',
      verify: 'Verify',
      nav: {
        modeSwitchAria: 'Mode switch',
        dynamicTabsAria: 'Open editor tabs'
      },
      modes: {
        composer: 'Site Settings',
        editor: 'Editor',
        updates: 'System Updates'
      },
      tree: {
        aria: 'Content files',
        title: 'Content',
        subtitle: 'Articles and pages',
        addArticle: '+ New article',
        addPage: 'Page',
        treeAria: 'Content file tree',
        kicker: 'Content structure',
        emptyTitle: 'Select a node',
        emptyMeta: 'Choose an item in the tree to manage its structure or edit a Markdown file.',
        welcome: 'Welcome',
        articles: 'Articles',
        pages: 'Pages',
        toggle: 'Toggle',
        rootKicker: 'Collection',
        rootMeta: ({ count }) => `${count} item${count === 1 ? '' : 's'}`,
        status: {
          added: 'Added',
          modified: 'Modified',
          deleted: 'Deleted',
          issue: 'Issue',
          checking: 'Checking',
          changedCount: ({ count }) => `${count} changed`,
          changedSummary: ({ total, added, modified, deleted }) => {
            const parts = [];
            if (added) parts.push(`${added} added`);
            if (modified) parts.push(`${modified} modified`);
            if (deleted) parts.push(`${deleted} deleted`);
            return parts.length ? `${total} changed: ${parts.join(', ')}` : `${total} changed`;
          },
          orderChanged: 'Order changed',
          deletedSummary: 'Deleted item'
        },
        system: 'System',
        siteSettings: 'Site Settings',
        themes: 'Themes',
        pressUpdates: 'Press Updates',
        sync: 'Publish',
        siteSettingsMeta: 'Edit site.yaml settings.',
        themesMeta: 'Theme packs.',
        systemUpdatesMeta: 'Review and apply Press updates.',
        syncMeta: 'Publish local changes to GitHub.',
        editorLanguage: 'Editor language',
        editorLanguageMeta: 'Change the editor interface language.',
        languages: 'languages',
        versions: 'versions',
        select: 'Select',
        article: 'article',
        page: 'page',
        articleEntry: 'Article',
        pageEntry: 'Page',
        articleEntryMeta: 'Manage article languages and versions.',
        pageEntryMeta: 'Manage page languages, titles, and files.',
        languageKicker: 'Article language',
        languageMeta: ({ count }) => `${count} version${count === 1 ? '' : 's'}`,
        deletedKicker: 'Deleted item',
        deletedMeta: 'This item was removed from the current draft. Restore it before publishing if you want to keep it.',
        deletedEntryMeta: 'This entry was removed from the current draft. Restore it before publishing if you want to keep it.',
        deletedLanguageMeta: 'This language was removed from the current draft. Restore it before publishing if you want to keep it.',
        deletedFileMeta: 'This file was removed from the current draft. Restore it before publishing if you want to keep it.',
        deletedPageLanguageMeta: 'This page language file was removed from the current draft. Restore it before publishing if you want to keep it.',
        deletedRestoreHint: 'Restore writes back the last loaded baseline value for this deleted item.',
        restoreDeleted: 'Restore',
        articleFile: 'Article file',
        pageFile: 'Page file',
        addLanguage: 'Add language',
        addVersion: 'Add version',
        removeLanguage: 'Remove language',
        reorderArticle: 'Reorder article',
        reorderPage: 'Reorder page',
        reorderVersion: 'Reorder version',
        key: 'Key',
        language: 'Language',
        fieldTitle: 'Title',
        location: 'Location',
        open: 'Open',
        remove: 'Remove',
        delete: 'Delete',
        version: 'Version',
        duplicateKey: 'That key already exists.',
        deleteEntryConfirm: ({ label }) => `Delete ${label}?`,
        deleteLanguageConfirm: ({ lang }) => `Remove ${lang}?`
      },
      welcome: {
        kicker: 'Getting started',
        title: 'Welcome to Press',
        meta: 'Where knowledge becomes pages.',
        stepsTitle: 'Start with three steps',
        step1Number: 'Step 1',
        step1Title: 'Set up the site',
        step1Detail: 'Confirm the site name, language, theme, and GitHub repository before editing content.',
        step1Button: 'Open Site Settings',
        step2Number: 'Step 2',
        step2Title: 'Add content',
        step2Detail: 'Use Articles for posts, notes, and tutorials. Use Pages for fixed navigation pages like About or History.',
        step2ArticlesButton: 'Open Articles',
        step2PagesButton: 'Open Pages',
        step3Number: 'Step 3',
        step3Title: 'Publish when ready',
        step3Detail: 'Saving keeps drafts local. Publish sends the changes you choose to GitHub.',
        step3Button: 'Open Publish',
        updatesTitle: 'Press Updates',
        updatesBody: 'Check editor and runtime updates without changing your articles, pages, or site settings.',
        updatesButton: 'Check updates',
        faqTitle: 'When a word looks unfamiliar',
        faqIntro: 'You do not need to read everything now. Open a question only when it helps.',
        faqPressQuestion: 'What is Press?',
        faqPressAnswer: 'Where knowledge becomes pages.',
        faqMarkdownQuestion: 'What is Markdown?',
        faqMarkdownAnswer: 'Markdown is a simple way to write headings, links, lists, images, and paragraphs as plain text.',
        faqArticlesPagesQuestion: 'What is the difference between Articles and Pages?',
        faqArticlesPagesAnswer: 'Articles are listed posts for blogs, notes, and tutorials. Pages are fixed navigation pages such as About or History.',
        faqFrontMatterQuestion: 'What is front matter?',
        faqFrontMatterAnswer: 'Front matter is the small settings block for a page or article, such as title, date, tags, excerpt, and cover image.',
        faqPublishQuestion: 'How do local edits and Publish work?',
        faqPublishAnswer: 'Saving keeps drafts on this computer. Publish sends the changes you choose to GitHub.',
        faqUpdatesQuestion: 'What do Press Updates change?',
        faqUpdatesAnswer: 'System Updates refresh editor and runtime files. They do not overwrite your articles, pages, or site settings.'
      },
      status: {
        localLabel: 'LOCAL',
        checkingDrafts: 'Checking drafts…',
        synced: 'Synced',
        upload: 'UPLOAD',
        remoteLabel: 'GitHub',
        loadingRepo: 'Loading GitHub settings…',
        checkingConnection: 'Checking connection…',
        clean: 'No local changes'
      },
      systemUpdates: {
        tabLabel: 'Press Updates',
        title: 'Press Updates',
        openDownload: 'Download release ZIP',
        downloadAssetLink: ({ name }) => `Download ${name}`,
        openReleasePage: 'View release on GitHub',
        downloadAndCheck: 'Download and check',
        selectArchive: 'Select downloaded ZIP',
        filesHeading: 'Pending system files',
        releaseNotes: 'Release notes',
        noNotes: 'This release does not include additional notes.',
        currentVersionLabel: ({ version }) => `Current Press: ${version}`,
        targetVersionLabel: ({ version }) => `Target Press: ${version}`,
        unknownVersion: 'unknown',
        latestLabel: ({ name, tag }) => `Latest release: ${name}${tag ? ` (${tag})` : ''}`,
        publishedLabel: ({ date }) => `Published on ${date}`,
        assetLabel: ({ name, size }) => `Asset: ${name} (${size})`,
        assetWithHash: ({ name, size, hash }) => `Asset: ${name} (${size}) — SHA-256 ${hash}`,
        noAsset: 'No Press system update package was attached to this release.',
        status: {
          idle: 'Download and check the latest release, or select a downloaded ZIP.',
          downloading: 'Downloading latest release ZIP…',
          reading: 'Reading archive…',
          verifying: 'Verifying archive…',
          noChanges: 'System files are up to date.',
          comparing: 'Comparing downloaded files…',
          changes: ({ count }) => `${count} system file${count === 1 ? '' : 's'} pending update.`
        },
        errors: {
          releaseFetch: 'Unable to load latest release information.',
          releaseRateLimited: 'GitHub API is rate limited. Try again later, or manually select a downloaded ZIP.',
          emptyFile: 'The selected file is empty.',
          invalidArchive: 'The selected ZIP could not be read as a Press release.',
          downloadFailed: 'Unable to download the latest system update package. Select a downloaded ZIP instead.',
          upgradeBlocked: ({ current, target, ranges }) => `Cannot update from ${current} to ${target}. Apply an intermediate Press release first. Supported source range: ${ranges}.`,
          themeRegistryUnavailable: ({ target, required }) => `Cannot verify installed themes before updating to ${target}. Make sure assets/themes/packs.json is readable before applying an update that requires ${required}.`,
          themeContractUpgradeBlocked: ({ target, required, themes }) => `Update installed themes to ${required} before updating to ${target}. Update or uninstall: ${themes}.`,
          themeContractUpgradeThemes: ({ themes }) => `Update or uninstall: ${themes}.`,
          contentModelUpgradeBlocked: ({ target, paths }) => `Publish the content model migration before updating to ${target}. Legacy YAML: ${paths}.`,
          sizeMismatch: ({ expected, actual }) => `The selected archive size (${actual}) does not match the release asset (${expected}).`,
          digestMismatch: 'The selected archive SHA-256 does not match the release asset.',
          generic: 'System update failed. Please try again.'
        },
        fileStatus: {
          added: 'New file',
          modified: 'Updated file'
        },
        summary: {
          added: 'new system file',
          modified: 'updated system file',
          deleted: 'deleted system file'
        }
      },
      themeManager: {
        status: {
          idle: 'No theme changes are staged.'
        }
      },
      currentFile: {
        status: {
          checking: 'Checking file…',
          existing: 'Existing file',
          missing: 'New file',
          error: 'Failed to load file'
        },
        meta: {
          checking: 'Checking…',
          checkingStarted: ({ time }) => `Checking… started ${time}`,
          lastChecked: ({ time }) => `Last checked: ${time}`
        },
        draft: {
          justNow: 'just now',
          savedHtml: ({ time }) => `Saved ${time}`,
          saved: 'Saved',
          savedConflictHtml: ({ time }) => `Saved ${time} (remote updated)`,
          conflict: 'Saved (remote updated)',
          available: 'Saved'
        }
      },
      frontMatter: {
        heading: 'Front matter',
        summaryDefault: 'Metadata for this post',
        summary: ({ count }) => (count ? `${count} metadata field${count === 1 ? '' : 's'} active` : 'No metadata yet'),
        help: 'Fill the metadata below. Leave a field empty to omit it from the file.',
        empty: 'No front matter fields yet. Add values to include metadata.',
        commonTitle: 'Common fields',
        commonDescription: 'Metadata used by cards, SEO, and article lists.',
        advancedTitle: 'Advanced fields',
        advancedDescription: 'Supplemental metadata for sharing images, version badges, and AI labels.',
        booleanLabel: 'Enabled',
        listHint: 'One item per line',
        clear: 'Clear',
        fields: {
          title: 'Title',
          excerpt: 'Excerpt',
          author: 'Author',
          date: 'Date',
          tags: 'Tags',
          image: 'Primary image',
          draft: 'Draft',
          version: 'Version',
          ai: 'AI generated'
        },
        hints: {
          title: 'Shown on cards and the browser title.',
          excerpt: 'Short summary for cards and SEO.',
          date: 'Publish date (ISO format recommended, e.g. 2024-03-18).',
          tags: 'Enter one tag per line. Used for grouping and search.',
          image: 'Fallback image for social previews.',
          draft: 'Mark as draft to exclude from listings.',
          version: 'Displayed as a version badge if provided.',
          ai: 'Mark when the content is AI generated or assisted.'
        }
      },
      toolbar: {
        wrap: 'Wrap:',
        wrapOn: 'on',
        wrapOff: 'off',
        view: 'View:',
        viewEdit: 'Editor',
        viewBlocks: 'Blocks',
        viewPreview: 'Preview',
        protection: 'Protection',
        save: 'Save',
        discard: 'Discard',
        wrapAria: 'Wrap setting',
        viewAria: 'View switch'
      },
      toast: {
        openAction: 'Open',
        closeAria: 'Close notification'
      },
      toasts: {
        remoteMarkdownMismatch: 'Remote markdown differs from the local draft. Review the changes before continuing.',
        markdownSynced: 'Markdown synchronized with GitHub.',
        remoteCheckCanceledUseRefresh: 'Remote check canceled. Use Refresh after your commit is ready.',
        yamlParseFailed: ({ label }) => `Fetched ${label} but failed to parse YAML.`,
        yamlUpdatedDifferently: ({ label }) => `${label} was updated differently on GitHub. Review the highlighted differences.`,
        yamlSynced: ({ label }) => `${label} synchronized with GitHub.`,
        remoteCheckCanceledClickRefresh: 'Remote check canceled. Click Refresh when your commit is ready.',
        popupBlocked: 'Your browser blocked the GitHub window. Allow pop-ups for this site and try again.',
        openGithubAction: 'Open GitHub',
        markdownOpenBeforeInsert: 'Open a markdown file before inserting images.',
        assetAttached: ({ label }) => `Attached ${label}`,
        imageReplaceTargetMissing: 'The image block no longer exists. Select an image block and try again.',
        imageDeleteTargetMissing: 'The image block no longer exists. Select an image block and try again.',
        assetDeleteUnsupported: 'Only local assets next to the current Markdown file can be deleted.',
        assetDeleteShared: 'This image resource is still referenced by another known Markdown document or another image block.',
        assetDeleteRejected: 'This image resource cannot be deleted yet.',
        assetPendingRemoved: ({ label }) => `Removed pending image asset ${label}.`,
        assetDeleteStaged: ({ label }) => `Staged ${label} for deletion.`,
        repositoryDeletionDraftsPending: 'Unable to delete files while local drafts are still pending.',
        repositoryDeletionDraftsBlocked: ({ sample, remaining }) => {
          const suffix = remaining ? `, +${remaining} more` : '';
          return `Publish blocked because deleted files still have local drafts: ${sample}${suffix}. Restore, publish, or discard those drafts before deleting the files.`;
        },
        noPendingChanges: 'No pending changes to commit.',
        siteWaitStopped: 'Stopped waiting for the live site. Your commit is already on GitHub, but it may take a few minutes to appear.',
        siteWaitTimedOut: 'Committed files to GitHub, but the live site did not update in time. Check the deploy status manually.',
        commitSuccess: ({ count }) => `Committed ${count} ${count === 1 ? 'file' : 'files'} to GitHub.`,
        commitSuccessWithWarnings: ({ count, warningCount }) => `Committed ${count} ${count === 1 ? 'file' : 'files'} to GitHub with ${warningCount} staging ${warningCount === 1 ? 'warning' : 'warnings'}.`,
        publishStagingWarnings: ({ count }) => `${count} optional staging ${count === 1 ? 'warning' : 'warnings'} recorded for this publish.`,
        githubCommitFailed: 'GitHub commit failed.',
        githubTokenRejected: 'GitHub rejected the access token. Enter a new Fine-grained Personal Access Token.',
        repoOwnerMissing: 'Configure repo.owner and repo.name in site.yaml to enable GitHub synchronization.',
        markdownOpenBeforePush: 'Open a markdown file before pushing to GitHub.',
        repoConfigMissing: 'Configure repo in site.yaml to enable GitHub push.',
        invalidMarkdownPath: 'Invalid markdown path.',
        unableLoadLatestMarkdown: 'Unable to load the latest markdown before pushing.',
        markdownNotReady: 'Markdown file is not ready to push yet.',
        unableResolveGithubFile: 'Unable to resolve GitHub URL for this file.',
        markdownOpenBeforeDiscard: 'Open a markdown file before discarding local changes.',
        noLocalMarkdownChanges: 'No local markdown changes to discard.',
        discardSuccess: ({ label }) => `Discarded local changes for ${label}.`,
        discardFailed: 'Failed to discard local markdown changes.',
        unableResolveYamlSync: 'Unable to resolve GitHub URL for YAML synchronization.',
        yamlUpToDate: ({ name }) => `${name} is up to date.`,
        yamlCopiedNoRepo: 'YAML copied. Configure repo in site.yaml to open GitHub.'
      },
      blocks: {
        toolbarAria: 'Block tools',
        listAria: 'Markdown blocks',
        virtualBlockAria: 'New block',
        virtualBlockPlaceholder: 'Type / to chose a block',
        commandMenuAria: 'Block selector',
        paragraph: 'Paragraph',
        heading: 'Heading',
        image: 'Image',
        table: 'Table',
        list: 'List',
        quote: 'Quote',
        code: 'Code',
        source: 'Markdown',
        articleCard: 'Article Card',
        uploadImage: 'Upload Image',
        cardSearch: 'Search articles...',
        cardEmpty: 'No matching articles',
        empty: 'No blocks yet.',
        actions: 'More actions',
        moveUp: 'Move up',
        moveDown: 'Move down',
        addBefore: 'Add before',
        addAfter: 'Add after',
        delete: 'Delete',
        imageAlt: 'Alt text',
        imagePath: 'Image path',
        replaceImage: 'Replace image',
        deleteImageResource: 'Delete resource',
        unordered: 'Bulleted',
        ordered: 'Numbered',
        task: 'Checklist',
        tableAddRow: 'Add row',
        tableAddColumn: 'Add column',
        tableDeleteRow: 'Delete row',
        tableDeleteColumn: 'Delete column',
        tableAlignment: 'Column alignment',
        tableAlignDefault: 'Default',
        tableAlignLeft: 'Left',
        tableAlignCenter: 'Center',
        tableAlignRight: 'Right',
        codeLanguage: 'Language',
        cardLabel: 'Card label',
        cardLocation: 'post/path/file.md',
        inlineToolbarAria: 'Inline formatting',
        inlineBold: 'Bold',
        inlineItalic: 'Italic',
        inlineStrike: 'Strikethrough',
        inlineCode: 'Inline code',
        inlineLink: 'Link',
        inlineMore: 'More formatting',
        linkPrompt: 'Link URL',
        linkText: 'Link text',
        linkHref: 'Link URL',
        linkTitle: 'Link title',
        unlink: 'Unlink',
        listAddItem: 'Add item',
        listRemoveItem: 'Remove item',
        imageTitle: 'Image title',
        sourceReason: {
          blank: 'This empty Markdown segment is preserved as source.',
          frontMatter: 'Front matter is preserved as raw Markdown so document metadata stays intact.',
          unclosedFence: 'This fenced code block is incomplete, so it is kept as Markdown source.',
          callout: 'This block uses callout-style Markdown that the visual block editor does not edit directly.',
          table: 'This table-like Markdown is kept as source because it is not a supported standard pipe table.',
          indentedList: 'This list starts with indentation, so it is kept as source to avoid changing whether it means a nested list or code-like Markdown.',
          mixedList: 'This list starts from an unsupported mixed indentation, so it is kept as Markdown source.',
          image: 'This paragraph contains inline image Markdown, so it is kept as source to avoid changing the mixed content.',
          rawHtml: 'This paragraph contains raw HTML outside inline code, so it is kept as Markdown source.',
          unsupported: 'This Markdown is kept as source because the block editor cannot safely convert it to a visual block without changing the original structure.'
        },
        sourceAutofix: {
          label: 'Autofix',
          indentedList: 'Autofix: remove the shared list indentation and convert this Markdown into a visual list block.',
          unsupported: 'Autofix'
        }
      },
      editorTools: {
        aria: 'Editor tools',
        formatGroupAria: 'Formatting shortcuts',
        bold: 'Bold',
        italic: 'Italic',
        strike: 'Strikethrough',
        heading: 'Heading',
        quote: 'Quote',
        code: 'Inline code',
        codeBlock: 'Code Block',
        articleCard: 'Article Card',
        insertCardTitle: 'Insert article card',
        insertImage: 'Insert Image',
        insertImageShort: 'Image',
        cardDialogAria: 'Insert article card',
        cardSearch: 'Search articles…',
        cardEmpty: 'No matching articles',
        hints: {
          bold: 'No text is selected. Select text first, then click Bold to surround it with ** **.',
          italic: 'No text is selected. Select text first, then click Italic to surround it with * *.',
          strike: 'No text is selected. Select text first, then click Strikethrough to surround it with ~~ ~~.',
          heading: 'Select lines or place the caret on an empty line, then click Heading to prepend "# ".',
          quote: 'Select lines or place the caret on an empty line, then click Quote to prepend "> ".',
          code: 'No text is selected. Select text first, then click Code to wrap it in backticks.',
          codeBlock: 'Select lines or place the caret on an empty line, then click Code Block to wrap them in ``` fences.',
          insertCard: 'Place the caret on an empty line, then click to insert an article card. If no articles appear, wait for the index to load or add entries in index.yaml.'
        }
      },
      editorPlaceholder: '# Hello Press\n\nStart typing Markdown…',
      editorTextareaAria: 'Markdown source',
      empty: {
        title: 'No editor is currently open',
        body: 'Select a Markdown file from the tree to start editing.'
      },
      composer: {
        fileSwitchAria: 'File switch',
        fileLabel: 'File:',
        fileArticles: 'Articles',
        filePages: 'Pages',
        fileSite: 'Site',
        addPost: 'Add Post Entry',
        addTab: 'Add Tab Entry',
        refresh: 'Refresh',
        refreshTitle: 'Fetch latest remote snapshot',
        refreshing: 'Refreshing…',
        discard: 'Discard',
        discardTitle: 'Discard local draft and reload remote file',
        changeSummary: 'Change summary',
        reviewChanges: 'Review changes',
        inlineEmpty: 'No entries to compare yet.',
        indexInlineAria: 'Old order for index.yaml',
        indexEditorAria: 'index.yaml editor',
        tabsInlineAria: 'Old order for tabs.yaml',
        tabsEditorAria: 'tabs.yaml editor',
        siteEditorAria: 'site.yaml editor',
        noLocalChangesToCommit: 'No local changes to commit.',
        noLocalChangesYet: 'No local changes yet.',
        dialogs: {
          cancel: 'Cancel',
          confirm: 'Confirm',
          close: 'Close'
        },
        statusMessages: {
          loadingConfig: 'Loading config…',
          restoredDraft: ({ label }) => `Restored local draft for ${label}`,
          contentModelMigrationReady: 'Legacy content YAML was normalized. Publish once before installing the next clean Press release.',
          refreshSuccess: ({ name }) => `${name} refreshed from remote`,
          remoteUpdated: 'Remote snapshot updated. Highlights now include remote differences.',
          remoteUnchanged: 'Remote snapshot unchanged.',
          refreshFailed: 'Failed to refresh remote snapshot'
        },
        site: {
          addLanguage: 'Add language',
          removeLanguage: 'Remove',
          noLanguages: 'No languages configured yet.',
          promptLanguage: 'Enter a language code (for example: en, chs, ja):',
          languageExists: 'That language already exists.',
          languageDefault: 'Default',
          languageAutoOption: 'Auto-detect (browser language)',
          publicLanguagePolicies: {
            ui: 'UI languages',
            content: 'Content languages',
            explicit: 'Explicit list'
          },
          languageWarnings: {
            'public-language-missing-ui': ({ language }) => `Public language ${language} has no UI translation bundle and will not be shown.`,
            'content-language-missing-ui': ({ language }) => `Content language ${language} has no UI translation bundle and will not be shown.`,
            'default-language-missing-content': ({ language }) => `Default language ${language} has no matching content.`,
            'public-language-missing-content': ({ language }) => `Public language ${language} has no matching content.`,
            'public-language-empty-fallback': ({ language }) => `No public languages resolved. Falling back to ${language}.`,
            'language-switcher-single-language': 'Language switcher is enabled but fewer than two public languages are available.'
          },
          addLink: 'Add link',
          removeLink: 'Remove',
          reorderLink: 'Drag to reorder link. Press Alt+Up or Alt+Down to move.',
          noLinks: 'No links configured.',
          linkLabelTitle: 'Label',
          linkLabelPlaceholder: 'Label',
          linkHrefTitle: 'URL',
          linkHrefPlaceholder: 'https://example.com',
          toggleEnabled: 'Enable',
          optionShow: 'Show',
          optionHide: 'Hide',
          repoOwner: 'Username',
          repoName: 'Repository',
          repoBranch: 'Branch',
          repoOwnerPrefix: '@',
          repoNamePrefix: 'repo:',
          repoBranchPrefix: 'branch:',
          sections: {
            identity: {
              title: 'Identity',
              description: 'Customize the site title, subtitle, and avatar shown in navigation.'
            },
            seo: {
              title: 'SEO & sharing',
              description: 'Provide metadata used for search engines and link previews.'
            },
            configuration: {
              title: 'Site Configuration',
              description: 'Control site behavior, theme defaults, and editor warnings.'
            },
            behavior: {
              title: 'Behavior',
              description: 'Control pagination and landing behavior.'
            },
            publicChrome: {
              title: 'Public chrome',
              description: 'Control which public site controls and navigation surfaces are visible.'
            },
            theme: {
              title: 'Theme',
              description: 'Pick default theme settings applied to visitors.'
            },
            comments: {
              title: 'Comments',
              description: 'Configure Press Annotate comments backed by Ekily Connect.'
            },
            repo: {
              title: 'Repository',
              description: 'Configure GitHub details for commits and issue links.'
            },
            assets: {
              title: 'Asset warnings',
              description: 'Warn editors about large image uploads.'
            },
            extras: {
              title: 'Other keys',
              description: 'Read-only keys detected in site.yaml (not editable here).'
            }
          },
          fields: {
            siteTitle: 'Site title',
            siteTitleHelp: 'Shown as the main title in navigation and metadata.',
            siteSubtitle: 'Site subtitle',
            siteSubtitleHelp: 'Displayed beneath the title in navigation.',
            avatar: 'Avatar',
            avatarHelp: 'Relative path or URL to the avatar image.',
            resourceURL: 'Resource URL',
            resourceURLHelp: 'Absolute URL that points to the published /wwwroot folder (optional).',
            contentRoot: 'Content root',
            contentRootHelp: 'Folder containing index.yaml and tabs.yaml.',
            siteDescription: 'Site description',
            siteDescriptionHelp: 'Optional description used for SEO and link previews.',
            siteKeywords: 'Site keywords',
            siteKeywordsHelp: 'Comma-separated keywords for SEO (optional).',
            profileLinks: 'Profile links',
            profileLinksHelp: 'List of profile or social links shown near the avatar.',
            defaultLanguage: 'Default language',
            defaultLanguageHelp: 'Language code to use when no browser preference is matched.',
            publicLanguages: 'Public languages',
            publicLanguagesHelp: 'Choose which languages the public site advertises in controls and SEO.',
            publicLanguageList: 'Public language list',
            publicLanguageListHelp: 'Comma-separated language codes used when Public languages is Explicit list.',
            contentOutdatedDays: 'Outdated threshold (days)',
            contentOutdatedDaysHelp: 'Highlight posts older than this many days. Leave blank to disable.',
            pageSize: 'Posts per page',
            pageSizeHelp: 'Maximum number of posts to display on the All Posts page.',
            showAllPosts: 'All Posts tab',
            showAllPostsHelp: 'Show the All Posts tab alongside other navigation tabs.',
            landingTab: 'Landing tab',
            landingTabHelp: 'Choose which tab opens first when the site loads.',
            landingTabAllPostsOption: 'All Posts tab',
            featureSearch: 'Search',
            featureSearchHelp: 'Show public search UI and allow the search route.',
            featureEditorEntry: 'Editor entry',
            featureEditorEntryHelp: 'Show the public editor shortcut. Hiding it is presentation-only and does not protect index_editor.html.',
            featureVisitorThemeControls: 'Visitor theme controls',
            featureVisitorThemeControlsHelp: 'Show the visitor tools panel for theme, language, and editor controls.',
            featureLanguageSwitcher: 'Language switcher',
            featureLanguageSwitcherHelp: 'Show language controls inside the visitor tools panel.',
            featureAllPosts: 'All Posts',
            featureAllPostsHelp: 'Show the All Posts route and navigation link.',
            featureFooterNav: 'Footer navigation',
            featureFooterNavHelp: 'Show secondary navigation in the public footer.',
            featureProfileLinks: 'Profile links',
            featureProfileLinksHelp: 'Show configured profile links in public site chrome.',
            featureTags: 'Tags',
            featureTagsHelp: 'Show public tag filters and tag sidebars.',
            featureToc: 'Table of contents',
            featureTocHelp: 'Show generated article or page table of contents.',
            featurePostMeta: 'Post metadata',
            featurePostMetaHelp: 'Show article metadata cards, outdated notices, and related public meta surfaces.',
            featureComments: 'Comments',
            featureCommentsHelp: 'Allow public comment rendering when Annotate is configured.',
            publicChromeHomeWarning: 'No reachable home is configured. Enable All Posts or add a tab page.',
            cardCoverFallback: 'Fallback card cover',
            cardCoverFallbackHelp: 'Generate a fallback cover image when a post has no cover.',
            errorOverlay: 'Error overlay',
            errorOverlayHelp: 'Show a client-side error overlay when runtime errors occur.',
            themeMode: 'Theme mode',
            themeModeHelp: 'Default theme mode (user/system/light/dark).',
            themePack: 'Theme pack',
            themePackHelp: 'Theme pack folder to load by default.',
            themeOverride: 'Lock theme',
            themeOverrideHelp: 'Force the selected theme even if visitors change it.',
            repo: 'GitHub repository',
            repoHelp: 'Required for commits, push to GitHub, and issue links.',
            annotateEnabled: 'Article comments',
            annotateEnabledHelp: 'Enable comments below article pages.',
            annotateConnectBaseUrl: 'Connect URL',
            annotateConnectBaseUrlHelp: 'Base URL for the Ekily Connect deployment that serves comment APIs.',
            annotateDiscussionCategory: 'Discussion category',
            annotateDiscussionCategoryHelp: 'GitHub Discussions category used for article comment threads.',
            assetLargeImage: 'Warn about large images',
            assetLargeImageHelp: 'Show a warning when attached images exceed the threshold.',
            assetLargeImageThreshold: 'Large image threshold (KB)',
            assetLargeImageThresholdHelp: 'File size in kilobytes that triggers the warning. Leave blank to use the default.',
            extras: 'Preserved keys',
            extrasHelp: 'These keys stay in site.yaml but must be edited manually.'
          }
        },
        entryRow: {
          gripHint: 'Drag to reorder',
          details: 'Details',
          delete: 'Delete'
        },
        languages: {
          count: ({ count }) => `${count} ${count === 1 ? 'language' : 'languages'}`,
          addVersion: '+ Version',
          removeLanguage: 'Remove language',
          addLanguage: '+ Add language',
          removedVersions: ({ versions }) => `Removed: ${versions}`,
          placeholders: {
            indexPath: 'post/.../file.md',
            tabPath: 'tab/.../file.md'
          },
          fields: {
            title: 'Title',
            location: 'Location'
          },
          actions: {
            edit: 'Edit',
            open: 'Open in editor',
            moveUp: 'Move up',
            moveDown: 'Move down',
            remove: 'Remove'
          }
        },
        entryKinds: {
          post: {
            label: 'post',
            confirm: 'Add Post Entry',
            placeholder: 'Post key',
            message: 'Enter a new post key (letters and numbers only):'
          },
          tab: {
            label: 'tab',
            confirm: 'Add Tab Entry',
            placeholder: 'Tab key',
            message: 'Enter a new tab key (letters and numbers only):'
          }
        },
        diff: {
          heading: 'Changes',
          title: ({ label }) => `Changes — ${label}`,
          close: 'Close',
          subtitle: {
            default: 'Review differences compared to the remote baseline.',
            overview: 'Review a quick summary of the unsynced changes.',
            entries: 'Inspect added, removed, and modified entries.',
            order: 'Remote baseline (left) · Current order (right)'
          },
          tabs: {
            overview: 'Overview',
            entries: 'Entries',
            order: 'Order'
          },
          order: {
            remoteTitle: 'Remote',
            currentTitle: 'Current',
            empty: 'No items to compare yet.',
            inlineAllNew: 'All current items are new compared with the baseline.',
            emptyKey: '(empty)',
            badges: {
              to: ({ index }) => `→ #${index}`,
              from: ({ index }) => `from #${index}`,
              removed: 'Removed',
              added: 'New'
            }
          },
          orderStats: {
            empty: 'No direct moves; changes come from additions/removals',
            moved: ({ count }) => `Moved ${count}`,
            added: ({ count }) => `+${count} new`,
            removed: ({ count }) => `-${count} removed`
          },
          lists: {
            more: ({ count }) => `+${count} more`
          },
          inlineChips: {
            added: ({ count }) => `+${count} added`,
            removed: ({ count }) => `-${count} removed`,
            modified: ({ count }) => `~${count} modified`,
            orderChanged: 'Order changed',
            orderParts: {
              moved: ({ count }) => `${count} moved`,
              added: ({ count }) => `+${count} new`,
              removed: ({ count }) => `-${count} removed`
            },
            orderSummary: ({ parts }) => `Order: ${parts}`,
            langs: ({ summary }) => `Langs: ${summary}`,
            none: 'Changes detected.'
          },
          inline: {
            title: 'Change summary',
            ariaOrder: ({ label }) => `Old order for ${label}`,
            openAria: ({ label }) => `Open change overview for ${label}`
          },
          overview: {
            empty: 'No changes detected for this file.',
            stats: {
              added: 'Added',
              removed: 'Removed',
              modified: 'Modified',
              order: 'Order',
              changed: 'Changed',
              unchanged: 'Unchanged'
            },
            blocks: {
              added: 'Added entries',
              removed: 'Removed entries',
              modified: 'Modified entries'
            },
            languagesImpacted: ({ languages }) => `Languages impacted: ${languages}`
          },
          entries: {
            noLanguageContent: 'No language content recorded.',
            snapshot: {
              indexValue: ({ count }) => `${count} value${count === 1 ? '' : 's'}`,
              emptyEntry: 'empty entry',
              tabTitle: ({ title }) => `title “${title}”`,
              tabLocation: ({ location }) => `location ${location}`
            },
            summary: ({ lang, summary }) => `${lang}: ${summary}`,
            state: {
              added: ({ lang }) => `${lang}: added`,
              removed: ({ lang }) => `${lang}: removed`,
              updatedFields: ({ lang, fields }) => `${lang}: updated ${fields}`
            },
            parts: {
              typeChanged: 'type changed',
              addedCount: ({ count }) => `+${count} new`,
              removedCount: ({ count }) => `-${count} removed`,
              updatedCount: ({ count }) => `${count} updated`,
              reordered: 'reordered',
              contentUpdated: 'content updated'
            },
            join: {
              comma: ', ',
              and: ' & '
            },
            fields: {
              title: 'title',
              location: 'location',
              content: 'content'
            },
            empty: 'No content differences detected.',
            sections: {
              added: 'Added entries',
              removed: 'Removed entries',
              modified: 'Modified entries'
            },
            orderOnly: 'Only ordering changed for this file.'
          }
        },
        github: {
          modal: {
            title: 'Synchronize with GitHub',
            subtitle: 'Provide a Fine-grained Personal Access Token with repository contents access.',
            connectTitle: 'Ekily Connect publishing',
            connectHelp: ({ baseUrl }) => `GitHub App publishing is configured through ${baseUrl}.`,
            connectReady: 'Sign in with GitHub when publishing. No personal access token is needed.',
            connectConnected: 'GitHub sign-in is ready for this browser session.',
            publishMethodConnect: 'Connect',
            publishMethodPat: 'Personal token',
            connectBaseUrlLabel: 'Connect URL',
            connectBaseUrlHelp: 'Choose a built-in Connect remote or enter a compatible deployment URL. This setting is stored only in this browser.',
            connectInvalidUrl: 'Enter a valid Connect URL. HTTPS is required unless the host is localhost.',
            connectFallback: 'Use a Fine-grained Personal Access Token instead',
            connectFallbackActive: 'Fine-grained token fallback is active for this publish.',
            connectFallbackHint: 'If Connect is unavailable or your account is not authorized, switch to the personal token fallback.',
            connectMissing: 'Connect publishing is not configured for this site.',
            connectAuthorizing: 'Authorizing with Connect…',
            connectPublishing: 'Creating commit through Connect…',
            connectNetworkError: 'Could not reach Connect. Check your connection.',
            connectPublishFailed: 'Connect publish failed.',
            connectPublishTimedOut: 'Connect is still working on this publish job. Check the publish receipt for the latest status.',
            connectAuthorizationFailed: 'Connect authorization failed.',
            connectAuthorizationCanceled: 'Connect authorization was canceled.',
            connectAuthorizationTimedOut: 'Connect authorization timed out. Try signing in again.',
            summaryTitle: 'The following files will be committed:',
            summaryTextFilesTitle: 'Content files',
            summarySystemFilesTitle: 'System files',
            summarySeoFilesTitle: 'SEO files',
            summaryAssetFilesTitle: 'Asset files',
            summaryEmpty: 'No pending files to commit.',
            tokenLabel: 'Fine-grained Personal Access Token',
            helpHtml: 'Create a token at <a href="https://github.com/settings/tokens?type=beta" target="_blank" rel="noopener">github.com/settings/tokens</a> with access to the repository\'s contents. The token is stored for this browser session only.',
            forget: 'Forget token',
            submit: 'Commit changes',
            errorRequired: 'Enter a Fine-grained Personal Access Token to continue.'
          },
          preview: {
            subtitle: 'Preview pending file before uploading to GitHub.',
            unavailable: 'Preview unavailable for this file.',
            untitled: 'Untitled file'
          }
        },
        dialogs: {
          cancel: 'Cancel',
          confirm: 'Confirm',
          close: 'Close'
        },
        addEntryPrompt: {
          hint: 'Use only English letters and numbers.',
          confirm: 'Add Entry',
          defaultType: 'entry',
          placeholder: 'Entry key',
          message: ({ label }) => `Enter a new ${label} key:`,
          errorEmpty: 'Key cannot be empty.',
          errorInvalid: 'Key must contain only English letters, numbers, underscores, or hyphens.',
          errorDuplicate: 'That key already exists. Choose a different key.'
        },
        versionPrompt: {
          label: 'version',
          confirm: 'Add version',
          placeholder: 'v2.0.0',
          message: ({ key, lang }) => `Enter a version for ${key} / ${lang}:`,
          hint: 'Use a v-prefixed version like v2.0.0.',
          errorEmpty: 'Version cannot be empty.',
          errorInvalid: 'Version must start with v, for example v2.0.0.',
          errorDuplicate: ({ version }) => `${version} already exists.`
        },
        discardConfirm: {
          messageReload: ({ label }) => `Discard local changes for ${label} and reload the remote file? This action cannot be undone.`,
          messageSimple: ({ label }) => `Discard local changes for ${label}? This action cannot be undone.`,
          closeTabMessage: ({ label }) => `Close ${label}? Closing this tab will discard local markdown changes.`,
          closeTabFallback: 'this tab',
          discard: 'Discard',
          discarding: 'Discarding…',
          successFresh: ({ label }) => `Discarded local changes; loaded fresh ${label}`,
          successCached: ({ label }) => `Discarded local changes; restored ${label} from cached snapshot`,
          failed: 'Failed to discard local changes'
        },
        markdown: {
          push: {
            labelDefault: 'Synchronize',
            labelCreate: 'Create on GitHub',
            labelUpdate: 'Synchronize',
            tooltips: {
              default: 'Copy draft to GitHub.',
              noRepo: 'Configure repo in site.yaml to enable GitHub push.',
              noFile: 'Open a markdown file to enable GitHub push.',
              error: 'Resolve file load error before pushing to GitHub.',
              checking: 'Checking remote version…',
              loading: 'Loading remote snapshot…',
              create: 'Copy draft and create this file on GitHub.',
              update: 'Copy draft and update this file on GitHub.'
            }
          },
          save: {
            label: 'Save',
            busy: 'Saving…',
            tooltips: {
              default: 'Save local markdown draft in your browser.',
              noFile: 'Open a markdown file before saving.',
              empty: 'Add markdown content before saving.',
              clean: 'No markdown changes to save.'
            },
            toastSuccess: 'Local draft saved.',
            toastError: 'Failed to save local draft.'
          },
          discard: {
            label: 'Discard',
            busy: 'Discarding…',
            tooltips: {
              default: 'Discard local markdown changes and restore the last loaded version.',
              noFile: 'Open a markdown file to discard local changes.',
              reload: 'Discard local markdown changes (remote snapshot will be reloaded).'
            }
          },
          protection: {
            label: 'Protection',
            labelProtected: 'Protected',
            labelUnprotected: 'Protection',
            tooltipNoFile: 'Open a markdown file before changing protection.',
            tooltipProtected: 'This article is encrypted. Change the password or disable protection.',
            tooltipUnprotected: 'Encrypt this article with a per-article password.',
            dialogTitle: 'Article password',
            dialogMessage: 'Enter the article password to continue.',
            passwordLabel: 'Password',
            confirmPasswordLabel: 'Confirm password',
            passwordRequired: 'Password is required to encrypt this article.',
            passwordRequiredOpen: 'Password is required to open this protected article.',
            passwordMismatch: 'Passwords do not match.',
            openTitle: 'Unlock protected article',
            openMessage: 'Enter the article password before loading it into the editor.',
            draftTitle: 'Unlock protected draft',
            draftMessage: 'Enter the article password to restore this encrypted local draft.',
            passwordTitle: 'Keep article encrypted',
            passwordMessage: 'Enter the article password so the draft can be saved encrypted.',
            enableTitle: 'Protect article',
            enableMessage: 'Set a password. Press encrypts the article body before saving or publishing.',
            changeTitle: 'Change article password',
            changeMessage: 'Set a new password. Existing local plaintext stays only in this open page.',
            changePrompt: 'This article is protected. Change its password?',
            disableConfirm: 'Disable protection and publish this article as plaintext?',
            enable: 'Enable protection',
            unlock: 'Unlock',
            keepEncrypted: 'Keep encrypted',
            changePassword: 'Change password',
            keepProtection: 'Keep protection',
            disable: 'Disable protection',
            enabledToast: 'Article protection enabled.',
            disabledToast: 'Article protection disabled.',
            passwordChangedToast: 'Article password changed.',
            unlockFailed: 'Unable to unlock with that password.',
            invalidEnvelope: 'Protected article envelope is invalid.',
            prepareFailed: 'Failed to prepare encrypted markdown.'
          },
          draftIndicator: {
            conflict: 'Local draft conflicts with remote file.',
            dirty: 'Unsaved changes pending in editor.',
            saved: 'Local draft saved in browser.'
          },
          currentFile: 'current file',
          fileFallback: 'markdown file',
          openBeforeEditor: 'Enter a markdown location before opening the editor.',
          toastCopiedCreate: 'Markdown copied. GitHub will open to create this file.',
          toastCopiedUpdate: 'Markdown copied. GitHub will open to update this file.',
          blockedCreate: 'Markdown copied. Click “Open GitHub” if the new tab did not appear so you can create this file.',
          blockedUpdate: 'Markdown copied. Click “Open GitHub” if the new tab did not appear so you can update this file.'
        },
        yaml: {
          toastCopiedUpdate: ({ name }) => `${name} copied. GitHub will open so you can paste the update.`,
          toastCopiedCreate: ({ name }) => `${name} copied. GitHub will open so you can create the file.`,
          blocked: ({ name }) => `${name} copied. Click “Open GitHub” if the new tab did not appear.`
        },
        remoteWatcher: {
          waitingForCreate: ({ label }) => `Waiting for GitHub to create ${label}`,
          waitingForUpdate: ({ label }) => `Waiting for GitHub to update ${label}`,
          waitingForCommitStatus: 'Waiting for GitHub commit…',
          checkingRemoteChanges: 'Checking remote changes…',
          waitingForCommit: 'Waiting for commit…',
          stopWaiting: 'Stop waiting',
          waitingForRemoteResponse: 'Waiting for remote response…',
          remoteCheckFailedRetry: 'Remote check failed. Retrying…',
          remoteFileNotFoundYet: 'Remote file not found yet…',
          remoteFileStillMissing: 'Remote file still missing…',
          updateDetectedRefreshing: 'Update detected. Refreshing…',
          remoteFileDiffersWaiting: 'Remote file still differs from local content. Waiting…',
          remoteFileExistsDiffersWaiting: 'Remote file exists but content differs. Waiting…',
          mismatchAdvice: 'If your GitHub commit intentionally differs, cancel and use Refresh to review it.',
          remoteCheckCanceled: 'Remote check canceled',
          errorWithDetail: ({ message }) => `Error: ${message}`,
          networkError: 'Network error',
          fileNotFoundOnServer: 'File not found on server',
          remoteSnapshotUpdated: 'Remote snapshot updated',
          waitingForGitHub: 'Waiting for GitHub…',
          preparing: 'Preparing…',
          waitingForLabel: ({ label }) => `Waiting for ${label} to update on GitHub…`,
          waitingForRemote: 'Waiting for remote…',
          yamlNotFoundYet: ({ label }) => `${label} not found on remote yet…`,
          remoteYamlDiffersWaiting: 'Remote YAML still differs from the local snapshot. Waiting…',
          remoteYamlExistsDiffersWaiting: 'Remote YAML updated but content differs. Waiting…',
          yamlMismatchAdvice: 'If the commit was different from your draft, cancel and click Refresh to pull it in.'
        },
      },
      github: {
        status: {
          arrowWarn: 'Check repo',
          arrowDefault: 'Status',
          loadingRepo: 'Loading GitHub settings…',
          readingConfig: 'Reading site.yaml for GitHub connection details…',
          repoNotConfigured: 'GitHub repository not configured',
          repoConfigHint: 'Add repo.owner and repo.name to site.yaml to enable pushing your drafts.',
          checkingRepo: 'Checking repository access…',
          rateLimited: 'GitHub rate limit hit. Try again later.',
          repoNotFound: 'Repository not found on GitHub.',
          networkError: 'Could not reach GitHub. Check your connection.',
          repoCheckFailed: 'Repository check failed.',
          repoConnectedDefault: ({ branch }) => `Repository connected · Default branch “${branch}”`,
          checkingBranch: 'Checking branch access…',
          branchNotFound: 'Branch not found on GitHub.',
          branchCheckFailed: 'Branch check failed.',
          repoConnected: 'Repository connected',
          configUnavailable: 'GitHub configuration unavailable',
          readFailed: 'Failed to read site.yaml.'
        }
      },
      footerNote: 'Crafted with ❤️ using <a href="https://ekilyhq.github.io/Press/" target="_blank" rel="noopener">Press</a>. Stay inspired and keep creating.'
    }
  }

export default translations;
