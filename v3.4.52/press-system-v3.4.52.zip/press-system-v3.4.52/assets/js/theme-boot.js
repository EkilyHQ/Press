// Early theme boot: set dark/light attribute ASAP and prepare theme pack
(function () {
  try {
    var saved = localStorage.getItem('theme');
    if (saved === 'dark') document.documentElement.setAttribute('data-theme', 'dark');
    else if (saved === 'light') document.documentElement.removeAttribute('data-theme');
    else if (window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches) {
      document.documentElement.setAttribute('data-theme', 'dark');
    }
  } catch (_) { /* ignore */ }

  // Compute native pack href once so we can apply quickly when the link exists.
  // External packs wait for runtime validation before their stylesheet is applied.
  var pack = 'native';
  try { pack = (localStorage.getItem('themePack') || 'native'); } catch (_) {}
  // Sanitize pack to a safe slug and encode when building URL
  try {
    pack = String(pack || '').toLowerCase().trim().replace(/[^a-z0-9_-]/g, '') || 'native';
  } catch (_) { pack = 'native'; }
  if (pack !== 'native') return;
  var href = 'assets/themes/' + encodeURIComponent(pack) + '/theme.css?v=press-system-v3.4.52';
  window.__themePackHref = href;

  // If the link tag exists already, set it; otherwise try briefly until it does
  var tries = 0;
  function trySet() {
    var link = document.getElementById('theme-pack');
    if (link) {
      if (link.getAttribute('href') !== href) link.setAttribute('href', href);
      return;
    }
    if (tries++ < 20) requestAnimationFrame(trySet);
  }
  trySet();
})();
