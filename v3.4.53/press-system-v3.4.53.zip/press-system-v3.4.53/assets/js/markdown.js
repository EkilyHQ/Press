import { resolveImageSrc, sanitizeUrl } from './safe-html.js?v=press-system-v3.4.53';
import { escapeHtml, escapeMarkdown } from './utils.js?v=press-system-v3.4.53';
import { stripFrontMatter } from './content.js?v=press-system-v3.4.53';

const DEFAULT_PARSE_LIMITS = {
  maxDepth: 8,
  maxInputLength: 512 * 1024,
  maxLines: 12000
};

function positiveInt(value, fallback) {
  const n = Number(value);
  if (!Number.isFinite(n) || n <= 0) return fallback;
  return Math.floor(n);
}

function nonNegativeInt(value, fallback) {
  const n = Number(value);
  if (!Number.isFinite(n) || n < 0) return fallback;
  return Math.floor(n);
}

function normalizeParseOptions(options = {}) {
  const input = options && typeof options === 'object' ? options : {};
  const limits = input.limits && typeof input.limits === 'object' ? input.limits : {};
  const imageResolution = input.imageResolution && typeof input.imageResolution === 'object'
    ? input.imageResolution
    : {};
  return {
    depth: Math.max(0, Math.floor(Number(input.depth) || 0)),
    maxDepth: nonNegativeInt(input.maxDepth ?? limits.maxDepth, DEFAULT_PARSE_LIMITS.maxDepth),
    maxInputLength: positiveInt(input.maxInputLength ?? limits.maxInputLength, DEFAULT_PARSE_LIMITS.maxInputLength),
    maxLines: positiveInt(input.maxLines ?? limits.maxLines, DEFAULT_PARSE_LIMITS.maxLines),
    imageResolution
  };
}

function renderMarkdownAsText(markdown) {
  const text = escapeHtml(String(markdown || ''));
  return text ? `<p>${text}</p>` : '';
}

function parseNestedMarkdown(markdown, baseDir, options) {
  return mdParse(markdown, baseDir, { ...options, depth: options.depth + 1 });
}

function normalizeCodeFenceLanguage(value) {
  const raw = String(value || '').trim().toLowerCase();
  return /^[a-z0-9][a-z0-9_.+-]{0,39}$/u.test(raw) ? raw : '';
}

function isPipeTableSeparator(line) {
  return !!parsePipeTableAlignments(line);
}

function parsePipeTableAlignments(line) {
  // Matches a classic Markdown table separator like:
  // | ----- | :----: | ----: |
  // and returns the per-column alignment requested by the colon markers.
  const s = String(line || '').trim();
  if (!s.startsWith('|')) return false;
  const cells = s.split('|').slice(1, -1); // drop leading/trailing pipes
  if (cells.length === 0) return null;
  const alignments = [];
  for (const c of cells) {
    const match = String(c || '').trim().match(/^(:)?-{3,}(:)?$/);
    if (!match) return null;
    const left = !!match[1];
    const right = !!match[2];
    alignments.push(left && right ? 'center' : (right ? 'right' : (left ? 'left' : '')));
  }
  return alignments;
}

function tableCellAlignAttr(alignments, cellIndex) {
  const align = Array.isArray(alignments) ? alignments[cellIndex] : '';
  return align ? ` class="press-table-align-${align}" style="text-align: ${align}"` : '';
}

function replaceInline(text, baseDir, options = {}) {
  const imageResolution = options && options.imageResolution && typeof options.imageResolution === 'object'
    ? options.imageResolution
    : {};
  const resolveInlineImageSrc = (src) => resolveImageSrc(src, baseDir, imageResolution);
  const parts = String(text || '').split('`');
  const mathTokens = [];
  const stashMath = (segment) => String(segment || '').replace(/&#040;([\s\S]+?)&#041;/g, (m, tex) => {
    const source = String(tex || '').trim();
    if (!source) return m;
    const token = `\u0000PRESS_MATH_${mathTokens.length}\u0000`;
    mathTokens.push(`<span class="press-math press-math-inline" data-tex="${source}"></span>`);
    return token;
  });
  const restoreMath = (segment) => String(segment || '').replace(/\u0000PRESS_MATH_(\d+)\u0000/g, (m, index) => {
    const html = mathTokens[Number(index)];
    return html || m;
  });
  let result = '';
  for (let i = 0; i < parts.length; i++) {
    if (i % 2 === 0) {
      result += restoreMath(stashMath(parts[i])
        .replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>')
        .replace(/\*(.*?)\*/g, '<em>$1</em>')
        // Obsidian-style embeds: ![[path|optional alt or options]]
        .replace(/!\[\[(.+?)\]\]/g, (m, inner) => {
          const raw = String(inner || '').trim();
          if (!raw) return m;
          // Split at first '|': left=src, right=alias/alt or options
          let src = raw;
          let alias = '';
          const pipeIdx = raw.indexOf('|');
          if (pipeIdx >= 0) {
            src = raw.slice(0, pipeIdx).trim();
            alias = raw.slice(pipeIdx + 1).trim();
          }
          if (!src) return m;
          const url = resolveInlineImageSrc(src);
          const isVideo = /\.(mp4|mov|webm|ogg)(\?.*)?$/i.test(src || '');
          if (isVideo) {
            const ext = String(src || '').split('?')[0].split('.').pop().toLowerCase();
            const type = ({ mp4: 'video/mp4', mov: 'video/quicktime', webm: 'video/webm', ogg: 'video/ogg' }[ext]) || 'video/mp4';
            const aria = alias ? ` aria-label="${alias}"` : '';
            return `<div class="post-video-wrap"><video class="post-video" controls playsinline preload="metadata"${aria}><source src="${url}" type="${type}">Sorry, your browser doesn't support embedded videos.</video></div>`;
          }
          // Fallback alt from alias or filename
          const fallbackAlt = alias || (String(src).split('/').pop() || 'image');
          return `<img src="${url}" alt="${fallbackAlt}">`;
        })
        // Images or Videos via image syntax: optional title
        .replace(/!\[(.*?)\]\(([^\s\)]*?)(?:\s*&quot;(.*?)&quot;)?\)/g, (m, alt, src, title) => {
          const url = resolveInlineImageSrc(src);
          const isVideo = /\.(mp4|mov|webm|ogg)(\?.*)?$/i.test(src || '');
          if (isVideo) {
            const ext = String(src || '').split('?')[0].split('.').pop().toLowerCase();
            const type = ({ mp4: 'video/mp4', mov: 'video/quicktime', webm: 'video/webm', ogg: 'video/ogg' }[ext]) || 'video/mp4';
            const t = title ? ` title="${title}"` : '';
            const aria = alt ? ` aria-label="${alt}"` : '';
            // Poster: allow specifying via title e.g. \"...|poster=frame.jpg\"
            // (Don't guess a basename image; missing files would block auto-capture poster logic.)
            let poster = null;
            if (title && String(title).trim()) {
              const parts = String(title).split(/\s*[|;]\s*/);
              for (const p of parts) {
                const m2 = p.match(/^poster\s*=\s*(.+)$/i);
                if (m2) { poster = m2[1]; break; }
              }
            }
            const posterAttr = poster ? ` poster="${resolveInlineImageSrc(poster)}"` : '';

            // Alternate sources for better compatibility
            let extraSources = [];
            if (title && String(title).trim()) {
              const parts = String(title).split(/\s*[|;]\s*/);
              for (const p of parts) {
                let m;
                // sources=foo.mp4,bar.webm (explicit paths)
                m = p.match(/^sources\s*=\s*(.+)$/i);
                if (m) {
                  const list = m[1].split(/\s*,\s*/).filter(Boolean);
                  extraSources.push(...list.map(s => ({ src: resolveInlineImageSrc(s), type: s.split('?')[0].split('.').pop().toLowerCase() })));
                  continue;
                }
                // formats=mp4,webm (same basename as primary)
                m = p.match(/^formats\s*=\s*(.+)$/i);
                if (m) {
                  try {
                    const baseNoQuery = String(src || '').split('?')[0];
                    const baseNoExt = baseNoQuery.replace(/\.[^.]+$/, '');
                    const fmts = m[1].split(/\s*,\s*/).filter(Boolean);
                    fmts.forEach(f => { extraSources.push({ src: resolveInlineImageSrc(`${baseNoExt}.${f}`), type: String(f).toLowerCase() }); });
                  } catch (_) { /* noop */ }
                }
              }
            }
            const typeFor = (e) => ({ mp4: 'video/mp4', mov: 'video/quicktime', webm: 'video/webm', ogg: 'video/ogg' }[e] || 'video/mp4');
            const extraHtml = extraSources
              .map(s => `<source src="${s.src}" type="${typeFor(s.type)}">`)
              .join('');
                    return `<div class="post-video-wrap"><video class="post-video" controls playsinline preload="metadata"${posterAttr}${t}${aria}><source src="${url}" type="${type}">${extraHtml}Sorry, your browser doesn't support embedded videos.</video></div>`;
          }
          const t = title ? ` title="${title}"` : '';
          return `<img src="${url}" alt="${alt}"${t}>`;
        })
        // Links (non-image): optional title, no lookbehind
        .replace(/(^|[^!])\[(.*?)\]\(([^\s\)]*?)(?:\s*&quot;(.*?)&quot;)?\)/g, (m, prefix, text2, href, title) => {
          const t = title ? ` title="${title}"` : '';
          return `${prefix}<a href="${sanitizeUrl(href)}"${t}>${text2}</a>`;
        })
        .replace(/~~(.*?)~~/g, '<del>$1</del>')
        .replace(/^\*\*\*$/gm, '<hr>')
        .replace(/^---$/gm, '<hr>'));
    } else { result += parts[i]; }
    if (i < parts.length - 1) { result += '`'; }
  }
  return result
    .replace(/\`(.*?)\`/g, '<code class="inline">$1</code>')
    .replace(/^\s*$/g, '<br>');
}

function renderInlineText(text, baseDir, options = {}) {
  return replaceInline(escapeHtml(String(text || '')), baseDir, options);
}

function tocParser(titleLevels, liTags) {
  // Build nested UL/LI markup as a string without reading from DOM
  let html = '';
  let prevLevel = 0;
  for (let i = 0; i < titleLevels.length; i++) {
    const raw = Number(titleLevels[i]) || 1;
    const level = Math.max(1, raw);
    const liTag = liTags[i];
    if (i === 0) {
      // Open lists up to first level
      for (let d = 0; d < level; d++) html += '<ul>';
    } else if (level > prevLevel) {
      // Deepen nesting; open one list per level increase
      for (let d = prevLevel; d < level; d++) html += '<ul>';
    } else if (level < prevLevel) {
      // Climb up: close current item, then for each level up close sublist and its parent item
      html += '</li>';
      for (let d = prevLevel; d > level; d--) html += '</ul></li>';
    } else {
      // Same level: close current item before starting next
      if (i > 0) html += '</li>';
    }
    // Start item for this heading
    html += `<li>${liTag}`;
    prevLevel = level;
  }
  // Close last item and all remaining lists
  html += '</li>';
  for (let d = prevLevel; d > 0; d--) html += '</ul>';
  return html;
}

function parseFenceLine(line) {
  const match = String(line || '').replace(/^\s*/, '').match(/^(`{3,}|~{3,})(.*)$/);
  if (!match) return null;
  const marker = match[1] || '';
  return { marker, char: marker[0], length: marker.length, info: match[2] || '' };
}

function isFenceCloseLine(line, fence) {
  if (!fence || !fence.char || !fence.length) return false;
  const marker = fence.char === '`' ? '`' : '~';
  const text = String(line || '').replace(/^\s*/, '');
  const re = new RegExp(`^${marker}{${fence.length},}\\s*$`);
  return re.test(text);
}

export function mdParse(markdown, baseDir, options = {}) {
  const parseOptions = normalizeParseOptions(options);
  if (parseOptions.depth > parseOptions.maxDepth) {
    return { post: renderMarkdownAsText(markdown), toc: '' };
  }

  // Strip front matter before parsing
  const rawMarkdown = String(markdown || '');
  const boundedMarkdown = rawMarkdown.length > parseOptions.maxInputLength
    ? rawMarkdown.slice(0, parseOptions.maxInputLength)
    : rawMarkdown;
  const cleanedMarkdown = stripFrontMatter(boundedMarkdown);
  let lines = String(cleanedMarkdown || '').split('\n');
  if (lines.length > parseOptions.maxLines) lines = lines.slice(0, parseOptions.maxLines);
  let html = '', tochtml = [], tochirc = [];
  let activeCodeFence = null, isInTable = false, isInTodo = false, isInPara = false;
  let tableAlignments = null;
  let codeLang = '';
  let codeBlockIndent = ''; // Store the indent level of the opening code block
  const closePara = () => { if (isInPara) { html += '</p>'; isInPara = false; } };
  // Basic list support (unordered/ordered, with simple nesting by indent)
  const listStack = []; // stack of { indent: number, type: 'ul'|'ol' }
  const countIndent = (s) => {
    let n = 0;
    for (let i = 0; i < s.length; i++) {
      if (s[i] === ' ') n += 1; else if (s[i] === '\t') n += 4; else break;
    }
    return n;
  };
  const closeAllLists = () => {
    while (listStack.length) {
      const last = listStack.pop();
      html += (last.type === 'ul') ? '</ul>' : '</ol>';
    }
  };

  for (let i = 0; i < lines.length; i++) {
    const line = lines[i];
    const lineIndent = line.match(/^\s*/)[0]; // Capture the indent of current line

    // Code blocks
    if (activeCodeFence) {
      if (isFenceCloseLine(line, activeCodeFence)) {
        activeCodeFence = null;
        codeBlockIndent = '';
        codeLang = '';
        html += '</code></pre>';
        continue;
      }
      // Remove the same level of indentation as the opening block
      const contentLine = line.startsWith(codeBlockIndent) ? line.slice(codeBlockIndent.length) : line;
      html += `${escapeHtml(contentLine)}\n`;
      continue;
    }

    const fence = parseFenceLine(line);
    if (fence) {
      closePara();
      activeCodeFence = fence;
      codeBlockIndent = lineIndent; // Remember the indent level
      codeLang = normalizeCodeFenceLanguage(fence.info.trim().split(/\s+/)[0] || '');
      // Calculate indent level (tab = 4 spaces, each level = 2rem roughly)
      const indentLevel = Math.floor(lineIndent.replace(/\t/g, '    ').length / 4);
      const indentClass = indentLevel > 0 ? ` code-indent-${indentLevel}` : '';
      html += `<pre class="code-block${indentClass}"><code${codeLang?` class=\"language-${codeLang}\"`:''}>`;
      continue;
    }

    const rawLine = escapeMarkdown(line);

    // Display math blocks. Only a line containing $$ opens/closes a block.
    // Unclosed blocks fall back to ordinary Markdown text below.
    if (String(line || '').trim() === '$$') {
      let j = i + 1;
      const mathLines = [];
      for (; j < lines.length; j++) {
        if (String(lines[j] || '').trim() === '$$') break;
        mathLines.push(lines[j]);
      }
      if (j < lines.length) {
        closeAllLists();
        closePara();
        const tex = escapeHtml(mathLines.join('\n'));
        html += `<div class="press-math press-math-display" data-tex="${tex}"></div>`;
        i = j;
        continue;
      }
    }

    // If currently inside a list but the next line starts a fenced code/table/blockquote/header,
    // we'll close lists right before handling those blocks (see below after matches).

    // Blockquote (with Obsidian-style Callouts support: > [!type] Title) 
    if (rawLine.startsWith('>')) {
      closeAllLists();
      closePara();
      let quote = `${rawLine.slice(1).trim()}`;
      let j = i + 1;
      for (; j < lines.length; j++) {
        if (lines[j].startsWith('>')) quote += `\n${lines[j].slice(1).trim()}`;
        else break;
      }

      // Detect Obsidian callout syntax in the first line: [!type] optional title
      try {
        const qLines = String(quote).split('\n');
        const first = (qLines[0] || '').trim();
        const m = first.match(/^\[!(\w+)\]\s*(.*)$/i);
        if (m) {
          const typeRaw = (m[1] || '').toLowerCase();
          const known = ['note','info','tip','hint','important','warning','caution','danger','error','success','example','quote','question'];
          const type = known.includes(typeRaw) ? typeRaw : 'note';
          const titleRaw = (m[2] || '').trim();
          // Default localized-ish labels when title is omitted
          const defaultLabel = (t) => ({
            note: 'Note', info: 'Info', tip: 'Tip', hint: 'Hint', important: 'Important',
            warning: 'Warning', caution: 'Caution', danger: 'Danger', error: 'Error',
            success: 'Success', example: 'Example', quote: 'Quote', question: 'Question'
          })[t] || 'Note';
          const label = titleRaw || defaultLabel(type);
          const iconFor = (t) => ({
            note: '📝', info: 'ℹ️', tip: '💡', hint: '💡', important: '📌',
            warning: '⚠️', caution: '⚠️', danger: '⛔', error: '⛔',
            success: '✅', example: '🧪', quote: '❝', question: '❓'
          })[t] || '📝';
          const role = (type === 'warning' || type === 'caution' || type === 'danger' || type === 'error') ? 'alert' : 'note';
          const body = qLines.slice(1).join('\n');
          const bodyHtml = parseNestedMarkdown(body, baseDir, parseOptions).post;
          const titleHtml = replaceInline(escapeHtml(label), baseDir, parseOptions);
          html += `<div class="callout callout-${type}" data-callout="${type}" role="${role}"><div class="callout-title"><span class="callout-icon" aria-hidden="true">${escapeHtml(iconFor(type))}</span><span class="callout-label">${titleHtml}</span></div><div class="callout-body">${bodyHtml}</div></div>`;
        } else {
          html += `<blockquote>${parseNestedMarkdown(quote, baseDir, parseOptions).post}</blockquote>`;
        }
      } catch (_) {
        // Fallback to plain blockquote rendering on any parsing error
        try { html += `<blockquote>${parseNestedMarkdown(quote, baseDir, parseOptions).post}</blockquote>`; } catch (_) { html += `<blockquote>${escapeHtml(quote)}</blockquote>`; }
      }
      i = j - 1;
      continue;
    }

    // Tables (GitHub-style pipe tables)
    if (rawLine.startsWith('|')) {
      closePara();
      const tabs = rawLine.split('|');
      if (!isInTable) {
        // Start a table only if the next line is a header separator row
        const nextAlignments = i + 1 < lines.length ? parsePipeTableAlignments(lines[i + 1]) : null;
        if (nextAlignments) {
          isInTable = true;
          tableAlignments = nextAlignments;
          html += '<div class="table-wrap"><table><thead><tr>';
          for (let j = 1; j < tabs.length - 1; j++) html += `<th${tableCellAlignAttr(tableAlignments, j - 1)}>${parseNestedMarkdown(tabs[j].trim(), baseDir, parseOptions).post}</th>`;
          html += '</tr></thead><tbody>';
          // Skip the separator line
          i += 1;
        } else {
          // Not a valid table header, treat as regular paragraph text
          if (!isInPara) { html += '<p>'; isInPara = true; }
          html += `${renderInlineText(rawLine, baseDir, parseOptions)}`;
          if (i + 1 < lines.length && escapeMarkdown(lines[i + 1]).trim() !== '') html += '<br>';
        }
      } else {
        // Inside a table body: ignore any stray separator lines
        if (isPipeTableSeparator(line)) { continue; }
        html += '<tr>';
        for (let j = 1; j < tabs.length - 1; j++) html += `<td${tableCellAlignAttr(tableAlignments, j - 1)}>${parseNestedMarkdown(tabs[j].trim(), baseDir, parseOptions).post}</td>`;
        html += '</tr>';
      }
      // Close table if the next line is not a pipe row
      if (isInTable && (i + 1 >= lines.length || !lines[i + 1].startsWith('|'))) {
        html += '</tbody></table></div>';
        isInTable = false;
        tableAlignments = null;
      }
      continue;
    } else if (isInTable) {
      html += '</tbody></table></div>';
      isInTable = false;
      tableAlignments = null;
    }

    // To-do list
    const match = rawLine.match(/^[-*] \[([ x])\]/);
    if (match) {
      closeAllLists();
      closePara();
      if (!isInTodo) { isInTodo = true; html += '<ul class="todo">'; }
      const taskText = renderInlineText(rawLine.slice(5).trim(), baseDir, parseOptions);
      html += match[1] === 'x'
        ? `<li><input type="checkbox" id="todo${i}" disabled checked><label for="todo${i}">${taskText}</label></li>`
        : `<li><input type="checkbox" id="todo${i}" disabled><label for="todo${i}">${taskText}</label></li>`;
      if (i + 1 >= lines.length || !escapeMarkdown(lines[i + 1]).match(/^[-*] \[([ x])\]/)) { html += '</ul>'; isInTodo = false; }
      continue;
    } else if (isInTodo) { html += '</ul>'; isInTodo = false; }

    // Standard unordered/ordered lists (not todo)
    const ulm = rawLine.match(/^(\s*)[-*+]\s+(.+)$/);
    const olm = ulm ? null : rawLine.match(/^(\s*)(\d{1,9})[\.)]\s+(.+)$/);
    if (ulm || olm) {
      const indent = countIndent((ulm ? ulm[1] : olm[1]) || '');
      const type = ulm ? 'ul' : 'ol';
      const content = ulm ? ulm[2] : olm[3];
      const itemStartNum = ulm ? null : Number(olm[2]);
      closePara();
      // Adjust nesting based on indent
      if (!listStack.length) {
        if (type === 'ul') html += '<ul>';
        else html += (itemStartNum && itemStartNum !== 1) ? `<ol start="${itemStartNum}">` : '<ol>';
        listStack.push({ indent, type });
      } else {
        let last = listStack[listStack.length - 1];
        if (indent > last.indent) {
          // New nested list
          if (type === 'ul') html += '<ul>';
          else html += (itemStartNum && itemStartNum !== 1) ? `<ol start="${itemStartNum}">` : '<ol>';
          listStack.push({ indent, type });
        } else {
          // Pop until indent fits
          while (listStack.length && indent < listStack[listStack.length - 1].indent) {
            const popped = listStack.pop();
            html += (popped.type === 'ul') ? '</ul>' : '</ol>';
          }
          // Ensure correct list type at current indent
          last = listStack[listStack.length - 1];
          if (!last || last.type !== type) {
            if (last && last.indent === indent) {
              const popped = listStack.pop();
              html += (popped.type === 'ul') ? '</ul>' : '</ol>';
            }
            if (type === 'ul') html += '<ul>';
            else html += (itemStartNum && itemStartNum !== 1) ? `<ol start="${itemStartNum}">` : '<ol>';
            listStack.push({ indent, type });
          }
        }
      }
      // List item content
      html += `<li>${renderInlineText(String(content).trim(), baseDir, parseOptions)}</li>`;
      // Continue to next line; we'll close lists when pattern breaks
      const next = (i + 1 < lines.length) ? escapeMarkdown(lines[i + 1]) : '';
      if (!next || (!next.match(/^(\s*)[-*+]\s+(.+)$/) && !next.match(/^(\s*)\d{1,9}[\.)]\s+(.+)$/))) {
        // Next line isn't a list item; close all open lists
        closeAllLists();
      }
      continue;
    } else if (listStack.length) {
      // Current line is not a list; ensure lists are closed
      closeAllLists();
    }

    // Headings
    if (rawLine.startsWith('#')) {
      closeAllLists();
      closePara();
      const level = rawLine.match(/^#+/)[0].length;
      const text = renderInlineText(rawLine.slice(level).trim(), baseDir, parseOptions);
      html += `<h${level} id="${i}"><a class="anchor" href="#${i}" aria-label="Permalink">#</a>${text}</h${level}>`;
      if (level >= 2 && level <= 3) {
        tochtml.push(`<a href="#${i}">${text}</a>`);
        tochirc.push(level);
      }
      continue;
    }

    // Blank line => close paragraph
    if (rawLine.trim() === '') { closeAllLists(); closePara(); continue; }

    // Regular paragraph text
    {
      const lineHtmlRaw = renderInlineText(rawLine, baseDir, parseOptions);
      const lineHtml = String(lineHtmlRaw || '').trim();
      // Skip lines that render to empty or a single <br>
      if (lineHtml && lineHtml !== '<br>') {
        if (!isInPara) { html += '<p>'; isInPara = true; }
        html += lineHtml;
        // Add soft line break when the next line is also paragraph text.
        if (i + 1 < lines.length) {
          const nextTrim = escapeMarkdown(lines[i + 1]).trim();
          if (nextTrim !== '') html += '<br>';
        }
      }
    }
  }

  if (isInPara) html += '</p>';
  if (isInTable) html += '</tbody></table>';
  if (isInTodo) html += '</ul>';
  if (listStack.length) { while (listStack.length) { const last = listStack.pop(); html += (last.type === 'ul') ? '</ul>' : '</ol>'; } }

  return { post: html, toc: `${tocParser(tochirc, tochtml)}` };
}
